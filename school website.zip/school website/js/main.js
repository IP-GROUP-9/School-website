// $(document).ready(function(){
// $nav = $('.nav');
// $toggleCollapse = $('.toggle-collapse');

// /*click event on toggle menu*/
// $toggleCollapse.click(function(){
//     $nav.toggleClass("collapse")
// })
// });

// let icons = document.querySelector('.icons');
// document.querySelector("#menu-btn").onclick = () =>{
//     icons.classList.toggle('active');
// }