
function contact(){
    var fn = document.getElementById("fn");
	var ln = document.getElementById("ln"); 
    var email = document.getElementById("email"); 
	var msg = document.getElementById("msg");
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if(fn.value=="" || fn.value==null){
        alert("Name can't be empty");
    }

    if(email.value.match(mailformat))
    {
        document.form1.text1.focus();
        //return true;
    }
    else if(email.value===""){
        alert("can't be empty");
    }
    else
    {
        alert("You have entered an invalid email address!");
        document.form1.text1.focus();
        //return false;
    }
}