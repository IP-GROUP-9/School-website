function donate(){
    var rd1 = document.getElementById("rd1");
    var rd2 = document.getElementById("rd2");
    var rd3 = document.getElementById("rd3");
    var rd4 = document.getElementById("rd4");
    var name = document.getElementById("name");
			
    if(name.value==0)
        alert("Can't donate, you have to enter yor donation name!!!")

    if(rd1.checked)
        alert("Dear " + name.value + " you have donated " + rd1.value + " Successfully!!!");
    else if(rd2.checked)
        alert("Dear " + name.value + " you have donated " + rd2.value + "Successfully!!!");
    else if(rd3.checked)
        alert("Dear " + name.value + " you have donated " + rd3.value + "Successfully!!!");
    else if(rd4.checked)
        alert("Dear " + name.value + " you have donated " + rd4.value + "Successfully!!!");
    else
        alert("No info about your donation!!!")

        var select = document.getElementById("Donation Frequency");
        alert("Your donation frequency is " + select.options[select.selectedIndex].value);

}

function contact(){
    var fn = document.getElementById("fn");
	var ln = document.getElementById("ln"); 
    var email = document.getElementById("email"); 
	var msg = document.getElementById("msg");
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if(fn.value=="" || fn.value==null){
        alert("Name can't be empty");
    }

    if(email.value.match(mailformat))
    {
        document.form1.text1.focus();
        return true;
    }
    else if(email.value===""){
        alert("can't be empty");
        return false;
    }
    else
    {
        alert("You have entered an invalid email address!");
        document.form1.text1.focus();
        return false;
    }
}
function CheckPassword() 
{ 
var psw = document.getElementById("psw");
var decimal=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
if(psw.value.match(decimal)) 
{ 
alert('Correct ')
return true;
}
else
{ 
alert('Wrong...!')
return false;
}
} 

function CheckCPassword() 
{ 
    var psw = document.getElementById("psw1");
    var cpsw = document.getElementById("cpsw");
    if(psw1.value==cpsw.value) 
    { 
        return true;
    }
    else
    { 
        alert('password and confirm password must be the same...!')
        return false;
    }
} 
